﻿using System;

namespace RSA
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите длину сообщения:");
            int l = Convert.ToInt32(Console.ReadLine());
            char[] s = new char[l];
            int[] mr = new int[l];
            Console.WriteLine("Вводите сообщение по буквам на русском языке");
            for (int j = 0; j < l; j++)
            {
                s[j] = Convert.ToChar(Console.ReadLine());
            }
            int q = 11, p = 3;
            int n = p * q;
            int r = 0, e = 7;
            double res = 0;
            for (int j = 0; j < l; j++)
            {
                switch (s[j])
                {
                    case 'А':
                        r = 1;
                        break;
                    case 'Б':
                        r = 2;
                        break;
                    case 'В':
                        r = 3;
                        break;
                    case 'Г':
                        r = 4;
                        break;
                    case 'Д':
                        r = 5;
                        break;
                    case 'Е':
                        r = 6;
                        break;
                    case 'Ё':
                        r = 7;
                        break;
                    case 'Ж':
                        r = 8;
                        break;
                    case 'З':
                        r = 9;
                        break;
                    case 'И':
                        r = 10;
                        break;
                    case 'Й':
                        r = 11;
                        break;
                    case 'К':
                        r = 12;
                        break;
                    case 'Л':
                        r = 13;
                        break;
                    case 'М':
                        r = 14;
                        break;
                    case 'Н':
                        r = 15;
                        break;
                    case 'О':
                        r = 16;
                        break;
                    case 'П':
                        r = 17;
                        break;
                    case 'Р':
                        r = 18;
                        break;
                    case 'С':
                        r = 19;
                        break;
                    case 'Т':
                        r = 20;
                        break;
                    case 'У':
                        r = 21;
                        break;
                    case 'Ф':
                        r = 22;
                        break;
                    case 'Х':
                        r = 23;
                        break;
                    case 'Ц':
                        r = 24;
                        break;
                    case 'Ч':
                        r = 25;
                        break;
                    case 'Ш':
                        r = 26;
                        break;
                    case 'Щ':
                        r = 27;
                        break;
                    case 'Ъ':
                        r = 28;
                        break;
                    case 'Ы':
                        r = 29;
                        break;
                    case 'Ь':
                        r = 30;
                        break;
                    case 'Э':
                        r = 31;
                        break;
                    case 'Ю':
                        r = 32;
                        break;
                    case 'Я':
                        r = 33;
                        break;
                }
                mr[j] = r;
            }
            Console.WriteLine("Зашифрованное сообщение: ");
            for (int i = 0; i < l; i++)
            {
                res = Math.Pow(mr[i], e) % n;
                Console.WriteLine(res);
            }
            Console.ReadKey();
        }
    }
}
